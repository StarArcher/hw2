
% Step 1: Read the data into a cell array
fileID = fopen('weather_data.txt', 'r'); % Open file for reading
data = textscan(fileID, '%s %f %f %f', 'Delimiter', ',', 'HeaderLines', 1);
fclose(fileID); % Close the file

% Step 2: Extract the numerical data into separate vectors
temperature = data{2}; % Temperature data
humidity = data{3}; % Humidity data
precipitation = data{4}; % Precipitation data

% Step 3: Calculate the average temperature, humidity, and total precipitation
avgTemperature = mean(temperature);
avgHumidity = mean(humidity);
totalPrecipitation = sum(precipitation);

% Step 4: Save the statistics to a new file 'weather_summary.txt'
fileID = fopen('weather_summary.txt', 'w'); % Open file for writing
fprintf(fileID, 'Average Temperature: %.2f\n', avgTemperature);
fprintf(fileID, 'Average Humidity: %.2f\n', avgHumidity);
fprintf(fileID, 'Total Precipitation: %.2f\n', totalPrecipitation);
fclose(fileID); % Close the file
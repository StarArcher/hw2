% Vector indicating population change over time
Population = [5000 5200 5350 5600 5800];

% Show the Population Vector
disp(num2str(Population))

% Calculate the growth rate
growth_rate = (Population(2:end) - Population(1:end-1)) ./ Population(1:end-1);

% Pair the population vector alongside each number's rate of growth for
% that year
pop_data = [Population; [0 growth_rate]];

% Create table of the two vectors
t = array2table(pop_data);

% Display the table
disp(t)

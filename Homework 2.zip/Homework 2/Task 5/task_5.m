% Open stocks file for reading
fileID = fopen("stock_data.txt","r");
data_stocks = fscanf(fileID,'%f');
fclose(fileID);

% Create variables for mean stock price, the highest stock price, and the
% lowest stock price
ave = mean(data_stocks);
peak = max(data_stocks);
valley = min(data_stocks);

% Calculate how much times the stock increased from one day to the next
price_increases = sum(diff(data_stocks) > 0);

% Print all results
fprintf('Average Closing Price: %.2f\n', ave);
fprintf('Highest Closing Price: %.2f\n', peak);
fprintf('Lowest Closing Price: %.2f\n', valley);
fprintf('Number of Days with Price Increase: %d\n', price_increases);

% Step a: Create vectors
planet_distances = [0.39, 0.72, 1.00, 1.52, 5.20, 9.58, 19.22, 30.06]; % AU
planet_sizes = [0.38, 0.95, 1.00, 0.53, 11.21, 9.45, 4.01, 3.88]; % Relative sizes

% Step b: Create figure with subplots
figure;

% Subplot 1: Scatter plot
subplot(2, 1, 1);
hold on;
planet_names = {'Mercury', 'Venus', 'Earth', 'Mars', 'Jupiter', 'Saturn', 'Uranus', 'Neptune'};
colors = lines(numel(planet_names));

for i = 1:length(planet_names)
    scatter(planet_distances(i), planet_sizes(i), 100 * planet_sizes(i), colors(i,:), 'filled', 'DisplayName', planet_names{i});
end
xlabel('Distance from Sun (AU)');
ylabel('Relative Size (Earth = 1)');
title('Planet Distances vs. Sizes');
legend('Location', 'northeastoutside');
hold off;

% Subplot 2: Bar chart
subplot(2, 1, 2);
bar(planet_distances, 'FaceColor', [0 0.5 0.8]);
xticks(1:length(planet_names));
xticklabels(planet_names);
xlabel('Planets');
ylabel('Distance from Sun (AU)');
title('Distances of Planets from the Sun');

% Step d: Save the figure
saveas(gcf, 'solar_system_visualization.png');

function encrypted_message = caesar_cipher(message, shift)
    % Ensure that shift is within the range of 1 to 25
    shift = mod(shift, 26);

    % Initialize an empty string to hold the encrypted message
    encrypted_message = '';

    % Loop through each character in the input message
    for i = 1:length(message)
        current_char = message(i); % Get the current character
        if isletter(current_char) && current_char >= 'a' && current_char <= 'z'
            % Shift the character using ASCII values
            shifted_char = mod((double(current_char) - double('a') + shift), 26) + double('a');
            encrypted_message = [encrypted_message, char(shifted_char)]; % Append to the result
        else
            % If not a letter, append the character as is
            encrypted_message = [encrypted_message, current_char];
        end
    end
end

% Main script to use the caesar_cipher function

% Prompt the user for the message to encrypt
message = input('Enter the message to encrypt (lowercase letters only): ', 's');

% Prompt the user for the shift value
shift = input('Enter the shift value (1 to 25): ');

% Call the caesar_cipher function to encrypt the message
encrypted_message = caesar_cipher(message, shift);

% Display the original and encrypted messages
fprintf('Original Message: %s\n', message);
fprintf('Encrypted Message: %s\n', encrypted_message);